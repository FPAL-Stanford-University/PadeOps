/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-altivec.h"
#include "../common/hc2cbdftv_8.c"
