/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-generic128.h"
#include "../common/hc2cfdftv_12.c"
