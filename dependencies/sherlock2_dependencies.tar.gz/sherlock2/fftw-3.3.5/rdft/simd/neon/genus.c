/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-neon.h"
#include "../common/genus.c"
