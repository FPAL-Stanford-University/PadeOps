/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-neon.h"
#include "../common/hc2cfdftv_2.c"
