/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx.h"
#include "../common/hc2cbdftv_20.c"
