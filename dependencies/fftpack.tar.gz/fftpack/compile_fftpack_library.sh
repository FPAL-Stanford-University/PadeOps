 #!/bin/sh

 set -e 
 # set -x


CWD=`pwd`
mkdir -p ${CWD}/lib/
${FC} -c -O5 -xHost dfftpack.f
ar rcs libfftpack.a dfftpack.o
mv libfftpack.a ${CWD}/lib/
rm *.o
