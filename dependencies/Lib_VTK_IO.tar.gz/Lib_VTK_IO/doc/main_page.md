project: Lib_VTK_IO
project_dir: ./src
output_dir: ./doc/html/publish/
project_github: https://github.com/szaghi/Lib_VTK_IO
summary: Pure Fortran (2003+) library to write and read data conforming the VTK standard
author: Stefano Zaghi
github: https://github.com/szaghi
email: stefano.zaghi@gmail.com
docmark: <
md_extensions: markdown_checklist.extension
display: public
         protected
         private

{!README.md!}
