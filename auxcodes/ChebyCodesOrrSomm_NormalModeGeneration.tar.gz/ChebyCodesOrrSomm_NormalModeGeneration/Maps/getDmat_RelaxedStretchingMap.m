function [D0map,D1map,D2map,D3map,D4map] = getDmat_RelaxedStretchingMap(a,p,xi,D0,D1,D2,D3,D4)

%% Compute metric terms and store them as diag matrices
metric_D1_for_D1 = sparse(diag((a + 1)./(a + xi.^(2.*p).*(2.*p + 1))));

metric_D1_for_D2 = sparse(diag(-(2.*p.*xi.^(2.*p - 1).*(2.*p + 1).*(a + 1).^2)./(a + xi.^(2.*p).*(2.*p + 1)).^3));
metric_D2_for_D2 = sparse(diag((a + 1).^2./(a + xi.^(2.*p).*(2.*p + 1)).^2));

metric_D1_for_D3 = sparse(diag((2.*p.*xi.^(2.*p - 2).*(2.*p + 1).*(a + 1).^3.*(a - 2.*a.*p + 6.*p.*xi.^(2.*p) + xi.^(2.*p) + 8.*p.^2.*xi.^(2.*p)))./(a + 2.*p.*xi.^(2.*p) + xi.^(2.*p)).^5));
metric_D2_for_D3 = sparse(diag(-(6.*p.*xi.^(2.*p - 1).*(2.*p + 1).*(a + 1).^3)./(a + xi.^(2.*p).*(2.*p + 1)).^4));
metric_D3_for_D3 = sparse(diag((a + 1).^3./(a + xi.^(2.*p).*(2.*p + 1)).^3));

metric_D1_for_D4 = sparse(diag(-(4.*p.*xi.^(2.*p - 3).*(2.*p + 1).*(a + 1).^4.*(2.*a.*xi.^(2.*p) + 11.*p.*xi.^(4.*p) - 3.*a.^2.*p + xi.^(4.*p) + a.^2 + 44.*p.^2.*xi.^(4.*p) + 76.*p.^3.*xi.^(4.*p) + 48.*p.^4.*xi.^(4.*p) + 2.*a.^2.*p.^2 - 8.*a.*p.^2.*xi.^(2.*p) - 32.*a.*p.^3.*xi.^(2.*p) + 8.*a.*p.*xi.^(2.*p)))./(a + 2.*p.*xi.^(2.*p) + xi.^(2.*p)).^7));
metric_D2_for_D4 = sparse(diag((4.*p.*xi.^(2.*p - 2).*(2.*p + 1).*(a + 1).^4.*(2.*a - 4.*a.*p + 15.*p.*xi.^(2.*p) + 2.*xi.^(2.*p) + 22.*p.^2.*xi.^(2.*p)))./(a + 2.*p.*xi.^(2.*p) + xi.^(2.*p)).^6));
metric_D3_for_D4 = sparse(diag(-(12.*p.*xi.^(2.*p - 1).*(2.*p + 1).*(a + 1).^4)./(a + xi.^(2.*p).*(2.*p + 1)).^5));
metric_D4_for_D4 = sparse(diag((a + 1).^4./(a + xi.^(2.*p).*(2.*p + 1)).^4));

%[D0,D1,D2,D3,D4]=Dmat(N); % Non - mapped operators on [-1,1]
D0map = D0;
D1map = metric_D1_for_D1*D1;
D2map = metric_D1_for_D2*D1 + metric_D2_for_D2*D2;
D3map = metric_D1_for_D3*D1 + metric_D2_for_D3*D2 + metric_D3_for_D3*D3;
D4map = metric_D1_for_D4*D1 + metric_D2_for_D4*D2 + metric_D3_for_D4*D3 + metric_D4_for_D4*D4;