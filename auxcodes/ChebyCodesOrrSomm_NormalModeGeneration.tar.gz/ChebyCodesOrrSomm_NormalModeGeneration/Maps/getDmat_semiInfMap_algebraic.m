function [D0map,D1map,D2map,D3map,D4map] = getDmat_semiInfMap_algebraic(xi,D0,D1,D2,D3,D4)

%% Compute metric terms and store them as diag matrices
metric_D1_for_D1 = sparse(diag((xi - 1).^2/2));

metric_D1_for_D2 = sparse(diag((xi - 1).^3/2));
metric_D2_for_D2 = sparse(diag((xi - 1).^4/4));

metric_D1_for_D3 = sparse(diag((3*(xi - 1).^4)/4));
metric_D2_for_D3 = sparse(diag((3*(xi - 1).^5)/4));
metric_D3_for_D3 = sparse(diag((xi - 1).^6/8));

metric_D1_for_D4 = sparse(diag((3*(xi - 1).^5)/2));
metric_D2_for_D4 = sparse(diag((9*(xi - 1).^6)/4));
metric_D3_for_D4 = sparse(diag((3*(xi - 1).^7)/4));
metric_D4_for_D4 = sparse(diag((xi - 1).^8/16));

D0map = D0;
D1map = metric_D1_for_D1*D1;
D2map = metric_D1_for_D2*D1 + metric_D2_for_D2*D2;
D3map = metric_D1_for_D3*D1 + metric_D2_for_D3*D2 + metric_D3_for_D3*D3;
D4map = metric_D1_for_D4*D1 + metric_D2_for_D4*D2 + metric_D3_for_D4*D3 + metric_D4_for_D4*D4;