function z = InfiniteMap_exponential(xi)
z =  atanh(xi);  z(1) = -1E10; z(end) = 1E10; % Fix the infinity value
