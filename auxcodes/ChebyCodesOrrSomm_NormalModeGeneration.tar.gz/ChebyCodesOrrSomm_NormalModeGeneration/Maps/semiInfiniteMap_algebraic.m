function z = semiInfiniteMap_algebraic(xi)
z = (1 + xi)./(1 - xi); z(end) = 1E10; % Fix the infinity value