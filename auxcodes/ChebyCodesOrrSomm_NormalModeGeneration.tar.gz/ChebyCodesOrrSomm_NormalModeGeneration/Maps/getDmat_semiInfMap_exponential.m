function [D0map,D1map,D2map,D3map,D4map] = getDmat_semiInfMap_exponential(xi,D0,D1,D2,D3,D4)
%% Compute metric terms and store them as diag matrices
metric_D1_for_D1 = sparse(diag((1 - xi)));

metric_D1_for_D2 = sparse(diag(xi - 1));
metric_D2_for_D2 = sparse(diag((xi - 1).^2));

metric_D1_for_D3 = sparse(diag(1 - xi));
metric_D2_for_D3 = sparse(diag(-3*(xi - 1).^2));
metric_D3_for_D3 = sparse(diag(-(xi - 1).^3));

metric_D1_for_D4 = sparse(diag(xi - 1));
metric_D2_for_D4 = sparse(diag((7*xi - 7).*(xi - 1)));
metric_D3_for_D4 = sparse(diag(6*(xi - 1).^3));
metric_D4_for_D4 = sparse(diag((xi - 1).^4));

D0map = D0;
D1map = metric_D1_for_D1*D1;
D2map = metric_D1_for_D2*D1 + metric_D2_for_D2*D2;
D3map = metric_D1_for_D3*D1 + metric_D2_for_D3*D2 + metric_D3_for_D3*D3;
D4map = metric_D1_for_D4*D1 + metric_D2_for_D4*D2 + metric_D3_for_D4*D3 + metric_D4_for_D4*D4;