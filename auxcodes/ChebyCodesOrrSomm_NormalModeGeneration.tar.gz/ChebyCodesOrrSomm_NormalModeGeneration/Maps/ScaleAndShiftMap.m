function z = ScaleAndShiftMap(xi,scale,shift)
z = scale*xi + shift;