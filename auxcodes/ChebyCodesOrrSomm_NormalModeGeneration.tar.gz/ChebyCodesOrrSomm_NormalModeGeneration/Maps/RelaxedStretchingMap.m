function z = RelaxedStretchingMap(xi,a,p)
z = (a*xi + xi.^(2*p + 1))./(1 + a);