function z = InfiniteMap_algebraic(xi)
z = xi./sqrt(1 - xi.^2); z(1) = -1E10; z(end) = 1E10; 
