function z = semiInfiniteMap_exponential(xi)
z = -log((1 - xi)/2);  z(end) = 1E10; % Fix the infinity value