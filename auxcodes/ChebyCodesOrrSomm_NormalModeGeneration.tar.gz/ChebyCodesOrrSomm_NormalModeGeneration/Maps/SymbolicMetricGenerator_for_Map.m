function [D1_D1, D1_D2, D2_D2, D1_D3, D2_D3, D3_D3, D1_D4, D2_D4, D3_D4, D4_D4] = SymbolicMetricGenerator_for_Map(f,xi)

% Jacobian
fp = diff(f);

% First derivative
D1_D1 = (simplify(1/fp));

% Second derivative
D1_D2 = (simplify((diff(D1_D1,xi))/fp));
D2_D2 = (simplify((D1_D1)/fp));

% Third derivative
D1_D3 = (simplify((diff(D1_D2,xi))/fp));
D2_D3 = (simplify((diff(D2_D2,xi) + D1_D2)/fp));
D3_D3 = (simplify((D2_D2)/fp));
 
% Fourth derivative
D1_D4 = (simplify((diff(D1_D3,xi))/fp));
D2_D4 = (simplify((diff(D2_D3,xi) + D1_D3)/fp));
D3_D4 = (simplify((diff(D3_D3,xi) + D2_D3)/fp));
D4_D4 = (simplify((D3_D3)/fp));

% Convert from symbolic to string
D1_D1 = vectorize(D1_D1);

D1_D2 = vectorize(D1_D2);
D2_D2 = vectorize(D2_D2);

D1_D3 = vectorize(D1_D3);
D2_D3 = vectorize(D2_D3);
D3_D3 = vectorize(D3_D3);

D1_D4 = vectorize(D1_D4);
D2_D4 = vectorize(D2_D4);
D3_D4 = vectorize(D3_D4);
D4_D4 = vectorize(D4_D4);