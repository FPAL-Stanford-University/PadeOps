function x = ChebCollocationPoints(N)
theta = linspace(0,pi,N+1);
x = fliplr(cos(theta))';