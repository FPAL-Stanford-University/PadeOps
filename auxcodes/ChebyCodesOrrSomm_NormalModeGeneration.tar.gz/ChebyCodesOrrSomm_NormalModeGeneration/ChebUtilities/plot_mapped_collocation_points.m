function plot_mapped_collocation_points(xi,z,fid)
figure(fid), clf, plot(xi,xi,'.k'), hold on, plot(xi,z,'ob')
legend('Chebyshev collocation points','Mapped collocation points','Location','northwest')
xlabel('\xi'), ylabel('z'), title('Mapped Chebyshev grid')
zdiff = z(3) - z(2);
set(gca,'fontsize',18), ylim([min([-1,z(2)-zdiff]),z(end-1)+zdiff])