function T = chebInterpOperator(x,N)
x = x(:);
n = length(x);
T = zeros(n,N+1);
T(:,1) = 1;
T(:,2) = x;
for i = 2:N
    T(:,i+1) = 2*x.*T(:,i) - T(:,i-1);
end