function dat = read_fortran_plane(fname, nx, ny, dtype)
fid =    fopen(fname,'r');
dat = fread(fid,nx*ny,dtype);
dat = reshape(dat,[nx ny]);
fclose(fid);