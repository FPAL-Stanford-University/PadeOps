function plot_yz(x,y,z,u,xid)
figure, surface(squeeze(y(xid,:,:))', squeeze(z(xid,:,:))', squeeze(u(xid,:,:))','edgecolor','none'), daspect([1 1 1])
xlabel('y','fontsize',16), ylabel('z','fontsize',16)
set(gca,'fontsize',16), colorbar, box on
xlim([min(y(:)) max(y(:))]), ylim([min(z(:)) max(z(:))])