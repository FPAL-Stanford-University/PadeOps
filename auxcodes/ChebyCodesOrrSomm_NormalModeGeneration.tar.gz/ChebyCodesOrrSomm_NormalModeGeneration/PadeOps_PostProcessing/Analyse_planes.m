clear, clc, close all

%% Enter data information
Run = 15;
basedir = '~/PadeOpsDump';
nx = 192; ny = 192; nz = 512;     % Problem size
Lx = 16*pi; Ly = 16*pi; Lz = 25;  % Domain size

% Generate the mesh
dz = Lz/nz; dx = Lx/nx; dy = Ly/ny;
zEdge = linspace(0,Lz,nz+1); zCell = 0.5*(zEdge(2:end) + zEdge(1:end-1))';
x = 0:dx:Lx-dx; y = 0:dy:Ly-dy;
[xG,yG,zG] = ndgrid(x,y,zCell);

% Enter the time step to analyze (This could be iterated over a for loop to
% create a video, or to analyse all the snapshots at once).
tstep = 500;

%% Let's first create the base state
Ubase =  1 - exp(-zG).*cos(zG); % This is true only if your x axis is facing the geostrophic flow vector. 
Vbase =  exp(-zG).*sin(zG);

%% Decide which field we want to analyse
fieldlabel = '.plu'; % Which field? plu: u velocity, plv: v velocity, plw: w velocity

%% Let's look at the xy - planes first

fid = 1;  % Start from subfigure number 1.
figure(1), clf
for sliceid = [5,15,30,50,80,150]       % where in z is this slice taken from? (Integer index)
    % Now construct the file name.
    fname = strcat(basedir,'/Run',sprintf('%2.2i',Run),'/Run',sprintf('%2.2i',Run),'_t',sprintf('%6.6i',tstep),'_z',sprintf('%5.5i',sliceid),fieldlabel);
    u_xy_plane = read_fortran_plane(fname, nx, ny, 'double'); % read in the data
    % Subtract out he base state
    u_xy_plane = u_xy_plane - Ubase(:,:,sliceid);
    % now plot the velocity on this slice
    figure(1)
    subplot(2,3,fid)
    
    surface(squeeze(xG(:,:,1))',squeeze(yG(:,:,1))',u_xy_plane','edgecolor','none'), daspect([1 1 1])
    colorbar, xlabel('x/H'), ylabel('y/H'), set(gca,'fontsize',16), xlim([0,Lx]), ylim([0,Ly]), box on
    title(strcat('Sliced at zid = ',num2str(sliceid),', time step=',num2str(tstep)))
    fid = fid + 1; % interate the figure number.
end


%% Let's also look at the yz planes
figure(2), clf
sliceid = 64;
% Now construct the file name.
fname = strcat(basedir,'/Run',sprintf('%2.2i',Run),'/Run',sprintf('%2.2i',Run),'_t',sprintf('%6.6i',tstep),'_x',sprintf('%5.5i',sliceid),fieldlabel);
u_yz_plane = read_fortran_plane(fname, ny, nz, 'double'); % read in the data
% Subtract out he base state
u_yz_plane = u_yz_plane - squeeze(Ubase(sliceid,:,:));
% now plot the velocity on this slice
subplot(2,1,1)
surface(squeeze(yG(1,:,:))',squeeze(zG(1,:,:))',u_yz_plane','edgecolor','none'), daspect([1 1 1])
colorbar, xlabel('y/H'), ylabel('z/H'), set(gca,'fontsize',16), xlim([0,Ly]), ylim([0,Lz]), box on
title(strcat('Sliced at xid = ',num2str(sliceid)))


%% Let's also look at the xz planes
sliceid = 64;
% Now construct the file name.
fname = strcat(basedir,'/Run',sprintf('%2.2i',Run),'/Run',sprintf('%2.2i',Run),'_t',sprintf('%6.6i',tstep),'_y',sprintf('%5.5i',sliceid),fieldlabel);
u_xz_plane = read_fortran_plane(fname, nx, nz, 'double'); % read in the data
% Subtract out he base state
u_xz_plane = u_xz_plane - squeeze(Ubase(:,sliceid,:));
% now plot the velocity on this slice
subplot(2,1,2), surface(squeeze(xG(:,1,:))',squeeze(zG(:,1,:))',u_xz_plane','edgecolor','none'), daspect([1 1 1])
colorbar, xlabel('x/H'), ylabel('z/H'), set(gca,'fontsize',16), xlim([0,Ly]), ylim([0,Lz]), box on
title(strcat('Sliced at yid = ',num2str(sliceid)))
