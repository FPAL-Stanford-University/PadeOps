function plot_xz(x,y,z,u,yid)
figure, surface(squeeze(x(:,yid,:))', squeeze(z(:,yid,:))', squeeze(u(:,yid,:))','edgecolor','none'), daspect([1 1 1])
xlabel('x','fontsize',16), ylabel('z','fontsize',16)
set(gca,'fontsize',16), colorbar, box on
xlim([min(x(:)) max(x(:))]), ylim([min(z(:)) max(z(:))])