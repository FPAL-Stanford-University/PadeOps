function plot_xy(x,y,z,u,zid)
figure, surface(squeeze(x(:,:,zid))', squeeze(y(:,:,zid))', squeeze(u(:,:,zid))','edgecolor','none'), daspect([1 1 1])
xlabel('x','fontsize',16), ylabel('y','fontsize',16)
set(gca,'fontsize',16), colorbar, box on
xlim([min(x(:)) max(x(:))]), ylim([min(y(:)) max(y(:))])