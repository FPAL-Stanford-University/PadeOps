clear, clc, close all
% Carefully read through this code to see how the file name is generated.
% You will most likely have to edit the part where the file names are
% generated. 

Run = 16;                         % Run number tag in PadeOps output
tidx = 240;                      % Time index tag in PadeOps output
basedir = '~/PadeOpsDump';        % Where is the data located 
Lx = 16*pi; Ly = 16*pi; Lz = 25;  % Specify the domain dimensions

%% First let's read in the domain/simulation information
label = 'info';
fname = strcat(basedir,'/Run',sprintf('%2.2i',Run),'/Run',sprintf('%2.2i',Run),'_',label,'_t',sprintf('%6.6i',tidx),'.out');
dat = load(fname,'-ascii');
t = dat(1);    % Flow time at this instant
nx = (dat(2)); % Domain size in x
ny = (dat(3)); % Domain size in y
nz = (dat(4)); % Domain size in z

%% Generate the mesh for the data to be read in
dz = Lz/nz; dx = Lx/nx; dy = Ly/ny;
zEdge = linspace(0,Lz,nz+1); zCell = 0.5*(zEdge(2:end) + zEdge(1:end-1))';
xCell = 0:dx:Lx-dx; yCell = 0:dy:Ly-dy;
[xG,yG,zG] = ndgrid(xCell,yCell,zCell); 

%% Now let's read in the 3 velocity fields 

% read u
label = 'uVel';
fname = strcat(basedir,'/Run',sprintf('%2.2i',Run),'/Run',sprintf('%2.2i',Run),'_',label,'_t',sprintf('%6.6i',tidx),'.out');
u = read_fortran_box(fname, nx, ny, nz, 'double');

% read v
label = 'vVel';
fname = strcat(basedir,'/Run',sprintf('%2.2i',Run),'/Run',sprintf('%2.2i',Run),'_',label,'_t',sprintf('%6.6i',tidx),'.out');
v = read_fortran_box(fname, nx, ny, nz, 'double');

% read w
label = 'wVel';
fname = strcat(basedir,'/Run',sprintf('%2.2i',Run),'/Run',sprintf('%2.2i',Run),'_',label,'_t',sprintf('%6.6i',tidx),'.out');
w = read_fortran_box(fname, nx, ny, nz, 'double');


% You should now compute the fluctuations by subtracting out the planar
% averaged mean profiles, since your perturbations are likely to be dwarfed
% by the magnitude of the mean/base flow fields. 


% You could visualize the velocity fields using the following commands
% plot_xy(xG, yG, zG, u, 19) <--- This would plot the 19th z-slice on the xy plane
% plot_yz(xG, yG, zG, u, 5 ) <--- This would plot the 5th  x-slice on the yz plane
% plot_xz(xG, yG, zG, u, 10) <--- This would plot the 10th y-slice on the xz plane