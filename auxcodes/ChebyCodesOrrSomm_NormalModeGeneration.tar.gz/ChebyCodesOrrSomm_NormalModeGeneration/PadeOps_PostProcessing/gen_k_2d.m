function [k1,k2] = gen_k_2d(N1,N2,dx1,dx2)
k1_ind = -N1/2 : N1/2 - 1;
k2_ind = -N2/2 : N2/2 - 1;
k1_wav = fftshift(k1_ind*(2*pi/(N1*dx1)));
k2_wav = fftshift(k2_ind*(2*pi/(N2*dx2)));
[k1,k2] = ndgrid(k1_wav,k2_wav);