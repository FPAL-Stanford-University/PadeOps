clear, clc, close all, format long

%% Set up the z-mesh and provide model inputs

N = 128;     % Number of Chebyshev polynomials (For very high accuracy use > 128)
ztop = 30;   % This value is used instead of 'infinity'

%% Generate the mapped chebyshev points and derivative operators for the Ekman Layer problem
[xi,z,D0,D1,D2,D4] = EkmanLayerAtmos_GridOps(N,ztop);

%% Perform a reference calculation (Melander, JFM 1983) for mu = 0 to check correctness
% Melander's solution is c_critical = 0.616301969005562 + 0i for the
% following parameters: 
R   = 54.155039249993; 
k   = 0.3162250644296; 
eps =     -23.3261087; 
mu  =               0; 

% Leibovich & Lele (JFM, 1985) reference solution is c_critical = 0.375 + 0i for the
% following parameters: 
% k   =  0.89; 
% eps =    -9; 
% mu  = 2.033; 


tic, [c,phi_hat,chi_hat] = EkmanLayerAtmos_EigenValueSolver(k,R,eps,mu,z,D0,D1,D2,D4); tsingle = toc();
disp(strcat('Time needed (in seconds) for each evaluation:',num2str(tsingle,'%-4.4f')))
disp('=============================================================')
disp('Reference Case (Melander 1983)')
disp(strcat('Least Damped Eigenvalue:',num2str(c,'%-8.8f')))
disp('=============================================================')

 
%% Growth rates for a large range of parameters
nk = 100; kmin = 0.05; kmax = 0.75;
nR = 100; Rmin = 25; Rmax = 400;
k_grid = linspace(kmin,kmax,nk);
R_grid = linspace(Rmin,Rmax,nR);

disp(strcat('Expected time (in seconds) to generate all growth rates:',num2str(nk*nR*tsingle,'%-4.2f')))

c_grid = zeros(nR,nk);
disp('Now calculating growth rates...')
for j = 1:nk
    for i = 1:nR
        c_grid(i,j) = EkmanLayerAtmos_EigenValueSolver(k_grid(j),R_grid(i),eps,mu,z,D0,D1,D2,D4);
    end
end
disp('Done!')

%% Plot the growth rate on a surface plot

figure(1)
surface(R_grid,k_grid,imag(c_grid)','edgecolor','none'), caxis([0 max(imag(c_grid(:)))])
colorbar, xlim([0 Rmax]), ylim([0 kmax]), box on, grid on, daspect([200 1 1])
% Compare this figure with Fig. 7 in Leibovich & Lele (JFM, 1983)

%% Additional Comments: 
% 1) If you are interested in computing just the neutral curve, it is
% better to wrap the Eigenvalue solver into another function and use fsolve
% to find the k_crit for each Reynolds number. 
%
% 2) The results for low values of k are likely to be inaccurate since the
% value used for ztop needs to be larger for small k. Since ztop increases,
% you need to use more Chebyshev polynomials (N) and the calculation cost
% is larger. One can instead fix the value of ztop and obtain new non-zero
% BCs at z=ztop, and compute c in an iterative manner. However,
% experimenting with this algorithm has show that it is less efficient
% than using a larger value of ztop, and maniputating the mapping by
% changing "a" and "p" values for the relaxed-stretching map (see
% Prep_EkmanLayerAtmos.m) for more information. 
%
% 3) It is also possible to solve the entire problem using mapping to
% [-1,1] -> [0,+inf] domain as is done in EkmanLayer_AtmosphericProblem.m
% test case in Orr-Sommerfeld examples directory. It is easy to see that
% such maps tend to result in highly ill-conditioned Orr-Sommerfeld
% operators, especially for low values of k. Hence, it is better to use a
% map [-1,1] -> [0,zTop] and increase the value of zTop until the
% eigenvalues are converged. 
