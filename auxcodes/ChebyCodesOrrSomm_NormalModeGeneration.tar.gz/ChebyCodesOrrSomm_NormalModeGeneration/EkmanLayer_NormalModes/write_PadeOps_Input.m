function write_PadeOps_Input(k_modes, beta_modes, uhat, vhat, what,Lx,Ly,Lz,filetag)
mode_info(:,1) = beta_modes;
mode_info(:,2) = k_modes;


init_info_real(:,1) = real(uhat(:));
init_info_real(:,2) = real(vhat(:));
init_info_real(:,3) = real(what(:));

init_info_imag(:,1) = imag(uhat(:));
init_info_imag(:,2) = imag(vhat(:));
init_info_imag(:,3) = imag(what(:));

domain_info = [Lx;Ly;Lz];

fname = strcat(filetag,'_domain_info.dat');
save(fname,'domain_info','-ascii','-double')

fname = strcat(filetag,'_mode_info.dat');
save(fname,'mode_info','-ascii','-double')

fname = strcat(filetag,'_init_info_real.dat');
save(fname,'init_info_real','-ascii','-double')

fname = strcat(filetag,'_init_info_imag.dat');
save(fname,'init_info_imag','-ascii','-double')

