clear, clc, close all
%% Set up the z-mesh and provide model inputs
ztop = 25;
N = 256;
eps = 0; % See Definition Provided in the problem statement
map = 1; % 1: [-1,1] -> [0,ztop]; 2:[-1,1] -> [0,+inf] (Better to use mapping 1 since it is better conditioned) 

%% Compute the mapped grid and derivative operators

xi = ChebCollocationPoints(N); % Get the Chebyshev collocation points
[D0,D1,D2,D3,D4]=Dmat(N);      % Get Chebyshev derivative operators
switch map
    case 1
        a = 0; p = 0;  % a = 0, p = 0 values result in no mapping. 
        xi_temp = RelaxedStretchingMap(xi,a,p);
        [D0,D1,D2,D3,D4] = getDmat_RelaxedStretchingMap(a,p,xi,D0,D1,D2,D3,D4);
        
        shift = ztop/2; scale = ztop/2;
        z = ScaleAndShiftMap(xi_temp,scale,shift);
        [D0,D1,D2,D3,D4] = getDmat_scale_and_shift(scale,xi_temp,D0,D1,D2,D3,D4);
    case 2
        z = semiInfiniteMap_algebraic(xi);
        [D0,D1,D2,D3,D4] = getDmat_semiInfMap_algebraic(xi,D0,D1,D2,D3,D4);
end


%% Define the Base flow profiles
U =  cosd(eps) - exp(-z).*cos(z + eps*pi/180);
V = -sind(eps) + exp(-z).*sin(z + eps*pi/180);

figure(1) % plot the profiles
subplot(1,2,1), plot(U,z), xlabel('U/G'), ylabel('z/D'), set(gca,'fontsize',16), grid on, ylim([0 25])
subplot(1,2,2), plot(V,z), xlabel('V/G'), ylabel('z/D'), set(gca,'fontsize',16), grid on, ylim([0 25])

%% Define the exact derivatives that show up in Orr-Sommerfeld equations
dUdz_exact   = 2.^(1./2).*sin(z + pi./4 + (eps.*pi)./180).*exp(-z);
d2Vdz2_exact = -2.*cos(z + (eps.*pi)./180).*exp(-z);

%% Numerically compute the derivatives using the chebyshev operators
uhat = fct(U);          % Fast chebyshev transform
vhat = fct(V);
dUdz_cheb   = D1*uhat;  % Note that the derivative operators also perform the inverse chebyshev transform
d2Vdz2_cheb = D2*vhat;  % Note that the derivative operators also perform the inverse chebyshev transform

%% Compute the error 
error_D1U = max(abs(dUdz_cheb - dUdz_exact))
error_D2V = max(abs(d2Vdz2_cheb - d2Vdz2_exact))
