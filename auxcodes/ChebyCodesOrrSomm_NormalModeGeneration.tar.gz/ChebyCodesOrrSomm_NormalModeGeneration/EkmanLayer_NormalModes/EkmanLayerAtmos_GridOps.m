function [xi,z,D0,D1,D2,D4] = EkmanLayerAtmos_GridOps(N,ztop)
%% INPUTS: 
%   N           : Number of Chebyshev polynomials to use
%   ztop        : Value of z in mapped grid to use instead of "infinity" (typically equal to something between 15-50)

%% OUTPUTS: 
%   xi          : Chebyshev collocation points on the interval [-1,1] (vector of length N+1)
%   x           : Mapped collocation points on the interval [0,ztop] (vector of length N+1)
%   D0/D1/D2/D4 : Chebyshev operators on the mapped grid

xi = ChebCollocationPoints(N); % Get the Chebyshev collocation points
[D0,D1,D2,D3,D4]=Dmat(N);      % Get Chebyshev derivative operators

a = 3; p = 1;                  % a = 0, p = 0 corressponds to no relaxation (original chebyshev points)
xi_temp = RelaxedStretchingMap(xi,a,p);
[D0,D1,D2,D3,D4] = getDmat_RelaxedStretchingMap(a,p,xi,D0,D1,D2,D3,D4);

shift = ztop/2; scale = ztop/2;
z = ScaleAndShiftMap(xi_temp,scale,shift);
[D0,D1,D2,~,D4] = getDmat_scale_and_shift(scale,xi_temp,D0,D1,D2,D3,D4);