clear, clc, close all, format long

%% Set up the z-mesh and provide model inputs

N = 64;     % Number of Chebyshev polynomials (For very high accuracy use > 128)
ztop = 30;  % This value is used instead of 'infinity'

%% Generate the mapped chebyshev points and derivative operators for the Ekman Layer problem
[xi,z,D0,D1,D2,D4] = EkmanLayerAtmos_GridOps(N,ztop);

%% Generate the DNS mesh
nx = 192; ny = 192; Lx = 16*pi; Ly = 16*pi;
dx = Lx/nx; dy = Ly/ny;
[k1,k2] = gen_k_2d(nx,ny,dx,dy);           % get the physical wavenumbers

kmode = sqrt(k1.^2 + k2.^2);
betamode = atan2d(-k1,(k2 + 1.d-15));

kx = -kmode.*sind(betamode);
ky =  kmode.*cosd(betamode);

% check the beta is computed correctly
max(abs(kx(:) - k1(:)))
max(abs(ky(:) - k2(:)))
%%
R = 300;
mu = 0;
c_grid = zeros(nx,ny);
disp('Now calculating growth rates...')
for j = 1:ny
    for i = 1:nx
        if (kmode(i,j)>=0.25)
            c_grid(i,j) = EkmanLayerAtmos_EigenValueSolver(kmode(i,j),R,betamode(i,j),mu,z,D0,D1,D2,D4);
        end
    end
    j
end
disp('Done!')

%% Plot the growth rate on a surface plot
c_grid(imag(c_grid)<0) = 0;
figure(1)
surface(k1',k2',imag(c_grid)','edgecolor','none'), caxis([0 max(imag(c_grid(:)))])
colorbar, xlim([min(k1(:)) max(k1(:))]), ylim([min(k2(:)) max(k2(:))]), box on, grid on