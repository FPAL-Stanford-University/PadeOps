function [c,phi_hat,chi_hat] = EkmanLayerAtmos_EigenValueSolver(k,R,eps,mu,z,D0,D1,D2,D4)
%% INPUTS: 
%   k              : Wavenumber
%   R              : Reynolds number
%   eps            : Coordinate rotation/Geostrophic angle (in degrees)
%   mu             : Latitude parameter (0 -> North Pole)
%   z              : Mapped grid (vector of size (N+1) where N is the number of Cheb polynomials being used).
%   D0/D1/D2/D4    : Mapped Chebyshev operators (Matrices of dimension (N+1,N+1))

%% OUTPUTS: 
%   c              : Least stable Eigen value (Complex number)
%   phi_hat        : Eigenfunction \phi corressponding to the least stable eigenvalue (Complex valued vector of length N+1))
%   chi_hat        : Eigenfunction \chi corressponding to the least stable eigenvalue (Complex valued vector of length N+1))

%% Check the domain size
if ((z(end) < 30) && (k<0.15)) 
    disp('WARNING: Value used for ZTOP is too low for the value of K being used. Solutions is likely to be inaccurate.')
end
%% Set the Base flow (on the mapped grid)

N = length(z) - 1; % Number of Chebyshev polynomials
v_base = -sind(eps) + exp(-z).*sin(z + eps*pi/180);
dudz_base   = 2.^(1./2).*sin(z + pi./4 + (eps.*pi)./180).*exp(-z);
d2vdz2_base = -2.*cos(z + (eps.*pi)./180).*exp(-z);

% Generate matrix multiplication operators for the two z-dependent functions
V   = sparse(diag(v_base));
Up  = sparse(diag(dudz_base));
Vpp = sparse(diag(d2vdz2_base));

%% Create the Orr-sommerfeld operator
L11 = -(1/(1i*k*R))*(D4 - 2*(k^2)*D2 + (k^4)*D0) + V*(D2 - (k^2)*D0) - Vpp*D0;
L12 = -(1/(1i*k*R))*(-2*1i*k*mu*D0 + 2*D1);

L21 = Up*D0 + 2*(1/(1i*k*R))*(D1 - 1i*k*mu*D0);
L22 = -(1/(1i*k*R))*(D2 - (k^2)*D0) + V*D0;

M11 = D2 - (k^2)*D0;
M12 = zeros(size(M11));
M22 = D0;
M21 = zeros(size(M22));

L = [L11,L12;L21,L22];
M = [M11,M12;M21,M22];

%% Embed Boundary conditions (Chebyshev-Tau method)

c_spurious = -600*1i; % set the spurious modes far away from the interesting modes

% BC1: \phi(z=0) = 0
L(1,1:N+1) = c_spurious*D0(1,:); % real part of this is ZERO.
M(1,1:N+1) = D0(1,:);
L(1,N+2:2*N+2) = 0;
M(1,N+2:2*N+2) = 0;

% BC2: d\phi_dz(z=0) = 0;
L(2,1:N+1) = c_spurious*D1(1,:); % real part of this is ZERO.
M(2,1:N+1) = D1(1,:);
L(2,N+2:2*N+2) = 0;
M(2,N+2:2*N+2) = 0;

% BC3: \phi(z=+inf) = 0
L(N+1,1:N+1) = c_spurious*D0(N+1,:); % real part of this is ZERO.
M(N+1,1:N+1) = D0(N+1,:);
L(N+1,N+2:2*N+2) = 0;
M(N+1,N+2:2*N+2) = 0;

% BC4: \chi(z=0) = 0
L(N+2,1:N+1) = 0;
M(N+2,1:N+1) = 0;
L(N+2,N+2:2*N+2) = c_spurious*D0(1,:); % real part of this is ZERO.
M(N+2,N+2:2*N+2) = D0(1,:);

% BC4: d2\phi_dz2(z=+inf) = 0
L(N,1:N+1) = c_spurious*D2(N+1,:); % real part of this is ZERO.
M(N,1:N+1) = D2(N+1,:);
L(N,N+2:2*N+2) = 0;
M(N,N+2:2*N+2) = 0;

% BC5: d\chi_dz(z=+inf) = 0
L(2*N+2,1:N+1) = 0;
M(2*N+2,1:N+1) = 0;
L(2*N+2,N+2:2*N+2) = c_spurious*D1(N+1,:); % real part of this is ZERO.
M(2*N+2,N+2:2*N+2) = D1(N+1,:);

%% Solve the Eigenvalue problem
OS = M\L;
[v,e] = eig(OS); e = diag(e);
[~,idx] = sort(imag(e),'descend'); % sort the eigenvalues with largest first.
Efunc = v(:,idx); Eval = e(idx);
c = Eval(1);

phi_real = D0*real(Efunc(1:N+1,1));
phi_imag = D0*imag(Efunc(1:N+1,1));
phi_hat = phi_real + 1i*phi_imag;

chi_real = D0*real(Efunc(N+2:2*N+2,1));
chi_imag = D0*imag(Efunc(N+2:2*N+2,1));
chi_hat = chi_real + 1i*chi_imag;
