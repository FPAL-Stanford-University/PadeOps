% This example code generates an initial condition using 2 orr sommerfeld
% modes

clear, clc, close all, format long
%% Linear/Eigenvalue solver inputs
N = 256;                                        % Number of Chebyshev polynomials (For very high accuracy use > 128)
ztop = 25;                                      % This value is used instead of 'infinity'
R   = 500;                                      % Reynolds number 
max_uhat_real = [1E-4 2E-3];                    % Normalize eigenfunctions such that the maximum value of real(uhat) is this. 
k   = [0.25 0.5];                               % Provide the wavenumber of the modes to create 
beta = [0 90];                                  % Provide the orientation of the rolls (degrees)
lambda = 90;                                    % Latitude (degrees)
mu  = -cotd(lambda)*cosd(beta);

PadeOpsInputFile_Tag = 'SampleInput_TwoModes';  % Tag the Padeops input file. 

alpha = 0;                                      % Let's fix alpha to be strictly zero for this assignment. 

eps = beta - alpha;
%% DNS code inputs
NZ_DNS = 256;                                   % Number of grid points to use in z
Lx = 16*pi; Ly = 16*pi; Lz = 25;                % Domain size 
%% Get the normal modes
% Get the map from [-1,1] -> [0,ztop]
xi = ChebCollocationPoints(N);                  % Get the Chebyshev collocation points
[D0,D1,D2,D3,D4]=Dmat(N);                       % Get Chebyshev derivative operators
shift = ztop/2; scale = ztop/2;                 % Define mapping parameters
z = ScaleAndShiftMap(xi,scale,shift);           % generate the map
[D0,D1,D2,~,D4] = getDmat_scale_and_shift(scale,xi,D0,D1,D2,D3,D4); % generate the mapped operators

%% Generate the DNS grid in the z
zEdges = linspace(0,Lz,NZ_DNS+1);
zCells = 0.5*(zEdges(2:end) + zEdges(1:end-1));
% Interpolate the eigenfunctions on the uniform grid in z
xi_interp = (zCells(:) - shift)/scale;
T = chebInterpOperator(xi_interp,N);

%% Get the eigefunctions/eigenvalues
uhatDNS = complex(zeros(NZ_DNS,length(k)));
vhatDNS = complex(zeros(NZ_DNS,length(k)));
whatDNS = complex(zeros(NZ_DNS,length(k)));
cmodes  = zeros(length(k),1);

for modeNum = 1:length(k)
    [c,phi_hat,chi_hat] = EkmanLayerAtmos_EigenValueSolver(k(modeNum),R,eps(modeNum),mu(modeNum),z,D0,D1,D2,D4);
    
    uhat = chi_hat;
    vhat = -D1*fct(phi_hat);            % -d(\phi_hat)/dz
    what = 1i*k(modeNum)*phi_hat;       %  d(\phi_hat)/dy
    normfactor = max(abs(real(uhat)))/max_uhat_real(modeNum); % normalize the eigenfunctions
    uhat = uhat/normfactor;
    vhat = vhat/normfactor;
    what = what/normfactor;
    
    %% Check incompressiblility
    dudx = 0;
    dvdy = 1i*k(modeNum)*vhat;
    dwdz = D1*fct(what);
    disp(strcat('Maximum divergence:',num2str(max(abs(dudx + dvdy + dwdz)))))

    uhatDNS(:,modeNum) = T*fct(uhat); vhatDNS(:,modeNum) = T*fct(vhat); whatDNS(:,modeNum) = T*fct(what);
    cmodes(modeNum) = c;
end

write_PadeOps_Input(k, beta, uhatDNS, vhatDNS, whatDNS,Lx,Ly,Lz,PadeOpsInputFile_Tag)
disp('PadeOps input file generated!')