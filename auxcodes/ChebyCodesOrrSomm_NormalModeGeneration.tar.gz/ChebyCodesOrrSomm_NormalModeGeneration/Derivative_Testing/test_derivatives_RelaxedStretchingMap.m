clear, clc%, close all

N = 64;

xi = ChebCollocationPoints(N);
a = 0.8; p = 2;

z = RelaxedStretchingMap(xi,a,p);
[D0,D1,D2,D3,D4]=Dmat(N);
[D0,D1,D2,D3,D4] = getDmat_RelaxedStretchingMap(a,p,xi,D0,D1,D2,D3,D4);

%% Declare function
f = tanh(z);
dfdz = 1 - (tanh(z).^2);
d2fdz2 = 2*tanh(z).*(tanh(z).^2 - 1);
d3fdz3 = -2*(tanh(z).^2 - 1).^2 - (4*tanh(z).^2).*(tanh(z).^2 - 1);
d4fdz4 = 8*tanh(z).*(3*tanh(z).^4 - 5*tanh(z).^2 + 2);
%% Compute the derivatives in chebyshev coords
fhat = fct(f);
df_dxi   = D1*fhat;
d2f_dxi2 = D2*fhat;
d3f_dxi3 = D3*fhat;
d4f_dxi4 = D4*fhat;


%% Compute the derivatives in physical coords
dfdz_cheb = D1*fhat;
d2fdz2_cheb = D2*fhat;
d3fdz3_cheb = D3*fhat;
d4fdz4_cheb = D4*fhat;

error_D1 = max(abs(dfdz_cheb - dfdz))
error_D2 = max(abs(d2fdz2_cheb - d2fdz2))
error_D3 = max(abs(d3fdz3_cheb - d3fdz3))
error_D4 = max(abs(d4fdz4_cheb - d4fdz4))