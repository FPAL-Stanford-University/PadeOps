clear, clc%, close all

N = 64;

xi = ChebCollocationPoints(N);
[D0,D1,D2,D3,D4]=Dmat(N);

% Lets first relax the stretching at the edges
a = 0.3; p = 3;
xi_temp = RelaxedStretchingMap(xi,a,p);
[D0,D1,D2,D3,D4] = getDmat_RelaxedStretchingMap(a,p,xi,D0,D1,D2,D3,D4);

% now let's scale the chebyshev points to a wider domain
shift = 0; scale = 15;
z = ScaleAndShiftMap(xi_temp,scale,shift);
[D0,D1,D2,D3,D4] = getDmat_scale_and_shift(scale,xi_temp,D0,D1,D2,D3,D4);

%% Declare function
f = tanh(z)./2 + 1./2;
dfdz = 1./2 - tanh(z).^2./2;
d2fdz2 = tanh(z).*(tanh(z).^2 - 1);
d3fdz3 = 4.*tanh(z).^2 - 3.*tanh(z).^4 - 1;
d4fdz4 = 4.*tanh(z).*(3.*tanh(z).^4 - 5.*tanh(z).^2 + 2);


%% Compute the derivatives in physical coords
fhat = fct(f);
dfdz_cheb = D1*fhat;
d2fdz2_cheb = D2*fhat;
d3fdz3_cheb = D3*fhat;
d4fdz4_cheb = D4*fhat;

error_D1 = max(abs(dfdz_cheb - dfdz))
error_D2 = max(abs(d2fdz2_cheb - d2fdz2))
error_D3 = max(abs(d3fdz3_cheb - d3fdz3))
error_D4 = max(abs(d4fdz4_cheb - d4fdz4))