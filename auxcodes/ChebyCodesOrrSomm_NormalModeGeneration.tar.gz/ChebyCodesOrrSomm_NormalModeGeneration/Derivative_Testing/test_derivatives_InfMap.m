clear, clc, close all

maptype  = 2; % 1: Algebraic,      2: Exponential
testfunc = 2; % 1: f(z) = tanh(z)  2: f(z) = exp(-z^2)
N = 8;      % Total number of collocation points

%% Construct the mapped grid and Chebyshev operators
xi = ChebCollocationPoints(N);
[D0,D1,D2,D3,D4]=Dmat(N); 

switch maptype
    case 1
        z = InfiniteMap_algebraic(xi);
        [D0,D1,D2,D3,D4] = getDmat_InfiniteMap_algebraic(xi,D0,D1,D2,D3,D4);
    case 2
        z = InfiniteMap_exponential(xi);
        [D0,D1,D2,D3,D4] = getDmat_InfiniteMap_exponential(xi,D0,D1,D2,D3,D4);
end

%% Declare function (and exact derivatives for testing accuracy)
switch testfunc
    case 1
        f = tanh(z)./2 + 1./2;
        dfdz = 1./2 - tanh(z).^2./2;
        d2fdz2 = tanh(z).*(tanh(z).^2 - 1);
        d3fdz3 = 4.*tanh(z).^2 - 3.*tanh(z).^4 - 1;
        d4fdz4 = 4.*tanh(z).*(3.*tanh(z).^4 - 5.*tanh(z).^2 + 2);
    case 2
        f = exp(-(z.^2));
        dfdz = -2.*z.*exp(-(z.^2));
        d2fdz2 = 2.*exp(-(z.^2)).*(2.*(z.^2) - 1);
        d3fdz3 = -4.*z.*exp(-(z.^2)).*(2.*(z.^2) - 3);
        d4fdz4 = 4.*exp(-(z.^2)).*(4.*(z.^4) - 12.*(z.^2) + 3);
end


%% Compute the derivatives in chebyshev coords
fhat = fct(f);

dfdz_cheb   = D1*fhat;
d2fdz2_cheb = D2*fhat;
d3fdz3_cheb = D3*fhat;
d4fdz4_cheb = D4*fhat;

error_D1 = max(abs(dfdz_cheb - dfdz))
error_D2 = max(abs(d2fdz2_cheb - d2fdz2))
error_D3 = max(abs(d3fdz3_cheb - d3fdz3))
error_D4 = max(abs(d4fdz4_cheb - d4fdz4))