%% Plane Poiseuille Flow (pressure driven channel flow)
%  Validation References: 
%  1) Orszag, S., J. Fluid Mech (1971)
%  2) Schmid & Henningson, Ed. 1, Springer-Verlag (2001), pp. 504
clear, clc, close all, format long

%% Input normal mode
alpha = 0.5; 
beta = 1;
R = 2000;  % Reynolds number
N = 128;     % Number of Chebyshev polynomials

%% Set chebyshev collocation grid
xi = ChebCollocationPoints(N); % Get the Chebyshev collocation points
[D0,D1,D2,D3,D4]=Dmat(N); % Get Chebyshev derivative operators

%% Map chebyshev grid to a new grid to relax stretching near corners
a = 0; p = 0; % a = 0, p = 0 is default chebyshev points. 
z = RelaxedStretchingMap(xi,a,p);
plot_mapped_collocation_points(xi,z,1)
[D0,D1,D2,D3,D4] = getDmat_RelaxedStretchingMap(a,p,xi,D0,D1,D2,D3,D4); % Get mapped operators

%% Set the Base flow (on the mapped grid)
u_base = 1 - z.^2;
d2udz2_base = D2*fct(u_base);

% Generate matrix multiplication operators for the two z-dependent functions
U = sparse(diag(u_base));  
Upp = sparse(diag(d2udz2_base));

%% Create the Orr-sommerfeld operator
k = sqrt(alpha^2 + beta^2);
L = -(1/(1i*alpha*R))*(D4 - 2*(k^2)*D2 + (k^4)*D0) + U*(D2 - (k^2)*D0) - Upp*D0;
M = D2 - (k^2)*D0;

%% Embed Boundary conditions (Chebyshev-Tau method)
c_spurious = -400*1i; % set the spurious modes far away from the interesting modes

% BC1: w(z=-1) = 0
L(1,:) = c_spurious*D0(1,:); % real part of this is ZERO. 
M(1,:) = D0(1,:);

% BC2: dwdz(z=-1) = 0
L(2,:) = c_spurious*D1(1,:); % real part of this is ZERO. 
M(2,:) = D1(1,:);

% BC3: w(z=+1) = 0
L(N+1,:) = c_spurious*D0(N+1,:); % real part of this is ZERO. 
M(N+1,:) = D0(N+1,:);

% BC4: dwdz(z=+1) = 0
L(N  ,:) = c_spurious*D1(N+1,:); % real part of this is ZERO.
M(N  ,:) = D1(N+1,:);

%% Solve the Eigenvalue problem
OS = M\L;
disp(strcat('Condition number of the Orr-Sommerfeld operator:',num2str(cond(OS),'%10.5e')))
[v,e] = eig(OS); e = diag(e);
[~,idx] = sort(imag(e),'descend'); % sort the eigenvalues with largest first. 
Efunc = v(:,idx); Eval = e(idx);
disp('First 8 least stable modes:')
disp(Eval(1:8))
disp(strcat('GrowthRate=',num2str(imag(Eval(1))*alpha)))

%% Plot the eigenvalues
figure(2), hold on, plot(real(Eval),imag(Eval),'x'), grid on
xlabel('c_r'), ylabel('c_i'), box on
xlim([0 1]), ylim([-3 0.1]), daspect([1 1 1])
set(gca,'fontsize',18)

%% Plot the eigenfunction 
w_real = D0*real(Efunc(:,1));
w_imag = D0*imag(Efunc(:,1));
figure(3), 
subplot(1,2,1), plot(w_real,z), xlabel('Real(w_{hat})'), ylim([-1 1])
subplot(1,2,2), plot(w_imag,z), xlabel('Imag(w_{hat})'), ylim([-1 1])