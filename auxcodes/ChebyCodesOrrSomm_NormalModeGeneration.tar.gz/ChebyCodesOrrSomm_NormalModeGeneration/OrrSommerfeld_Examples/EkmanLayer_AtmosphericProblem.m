%% Unstratified Ekman Layer (Atmospheric Problem)
%  Validation References: 
%  1) Melander, M.V., J. Fluid Mech. (1983)
%  2) Leibovich, S. & Lele, S. K., J. Fluid Mech. (1985)
clear, clc, close all, format long
%% Input normal mode and physical parameters
k = 0.25;      % Wavenumber
R = 200;       % Reynolds number
eps = -23.3;   % Frame - Geostrophic Angle (see Melander / Leibovich & Lele for definition)
mu = 0;        % Latitude measure (0 - North Pole)

%% Set map type and number of chebyshev polynomials
map = 1;       % 1: [-1,1]->[0,ztop], 2:[-1,1] -> [0,+inf]  (Map 1 is better conditioned)
ztop = 30;     % Used only when map == 1 
N = 256;       % Number of Chebyshev modes

%% Map chebyshev grid to a new scaled grid, and relax stretching at the end points
xi = ChebCollocationPoints(N); % Get the Chebyshev collocation points
[D0,D1,D2,D3,D4]=Dmat(N);      % Get Chebyshev derivative operators

switch map
    case 1
        a = 2; p = 8;         % a = 0, p = 0 corressponds to no relaxation (original chebyshev points)
        xi_temp = RelaxedStretchingMap(xi,a,p);
        [D0,D1,D2,D3,D4] = getDmat_RelaxedStretchingMap(a,p,xi,D0,D1,D2,D3,D4);
        
        shift = ztop/2; scale = ztop/2;
        z = ScaleAndShiftMap(xi_temp,scale,shift);
        [D0,D1,D2,D3,D4] = getDmat_scale_and_shift(scale,xi_temp,D0,D1,D2,D3,D4);
    case 2
        z = semiInfiniteMap_algebraic(xi);
        [D0,D1,D2,D3,D4] = getDmat_semiInfMap_algebraic(xi,D0,D1,D2,D3,D4);
end
plot_mapped_collocation_points(xi,z,1) % Plot the mapped collocation points

%% Set the Base flow (on the mapped grid)
u_base =  cosd(eps) - exp(-z).*cos(z + eps*pi/180);
v_base = -sind(eps) + exp(-z).*sin(z + eps*pi/180);

dudz_base   = 2.^(1./2).*sin(z + pi./4 + (eps.*pi)./180).*exp(-z);
d2vdz2_base = -2.*cos(z + (eps.*pi)./180).*exp(-z);

% Generate matrix multiplication operators for the two z-dependent functions
U   = sparse(diag(u_base));
V   = sparse(diag(v_base));
Up  = sparse(diag(dudz_base));
Vpp = sparse(diag(d2vdz2_base));

%% Create the Orr-sommerfeld operator
L11 = -(1/(1i*k*R))*(D4 - 2*(k^2)*D2 + (k^4)*D0) + V*(D2 - (k^2)*D0) - Vpp*D0;
L12 = -(1/(1i*k*R))*(-2*1i*k*mu*D0 + 2*D1);

L21 = Up*D0 + 2*(1/(1i*k*R))*(D1 - 1i*k*mu*D0);
L22 = -(1/(1i*k*R))*(D2 - (k^2)*D0) + V*D0;

M11 = D2 - (k^2)*D0;
M12 = zeros(size(M11));
M22 = D0;
M21 = zeros(size(M22));

L = [L11,L12;L21,L22];
M = [M11,M12;M21,M22];

%% Embed Boundary conditions (Chebyshev-Tau method)
c_spurious = -600*1i; % set the spurious modes far away from the interesting modes

% BC1: \phi(z=0) = 0
L(1,1:N+1) = c_spurious*D0(1,:); % real part of this is ZERO.
M(1,1:N+1) = D0(1,:);
L(1,N+2:2*N+2) = 0;
M(1,N+2:2*N+2) = 0;

% BC2: d\phi_dz(z=0) = 0;
L(2,1:N+1) = c_spurious*D1(1,:); % real part of this is ZERO.
M(2,1:N+1) = D1(1,:);
L(2,N+2:2*N+2) = 0;
M(2,N+2:2*N+2) = 0;

% BC3: \phi(z=+inf) = 0
L(N+1,1:N+1) = c_spurious*D0(N+1,:); % real part of this is ZERO.
M(N+1,1:N+1) = D0(N+1,:);
L(N+1,N+2:2*N+2) = 0;
M(N+1,N+2:2*N+2) = 0;

% BC4: \chi(z=0) = 0
L(N+2,1:N+1) = 0;
M(N+2,1:N+1) = 0;
L(N+2,N+2:2*N+2) = c_spurious*D0(1,:); % real part of this is ZERO.
M(N+2,N+2:2*N+2) = D0(1,:);


if (map == 1) 
    % BC4: d2\phi_dz2(z=+inf) = 0
    L(N,1:N+1) = c_spurious*D2(N+1,:); % real part of this is ZERO.
    M(N,1:N+1) = D2(N+1,:);
    L(N,N+2:2*N+2) = 0;
    M(N,N+2:2*N+2) = 0;
    
    % BC5: d\chi_dz(z=+inf) = 0
    L(2*N+2,1:N+1) = 0;
    M(2*N+2,1:N+1) = 0;
    L(2*N+2,N+2:2*N+2) = c_spurious*D1(N+1,:); % real part of this is ZERO.
    M(2*N+2,N+2:2*N+2) = D1(N+1,:);
end

%% Solve the Eigenvalue problem
OS = M\L;
disp(strcat('Condition number of the Orr-Sommerfeld operator:',num2str(cond(OS),'%10.5e')))
[v,e] = eig(OS); e = diag(e);
[~,idx] = sort(imag(e),'descend'); % sort the eigenvalues with largest first.
Efunc = v(:,idx); Eval = e(idx);

disp('First 8 least stable eigenvalues:')
disp(Eval(1:8))
%disp(strcat('Growth rate=',num2str(imag(Eval(1))*alpha)))

%% Plot the eigenvalues
figure(2), hold on, plot(real(Eval),imag(Eval),'x'), grid on
xlabel('c_r'), ylabel('c_i'), box on
xlim([0 1]), ylim([-0.05,max(imag(Eval))+0.02]), daspect([3 1 1])
set(gca,'fontsize',18)

 %% Plot the eigenfunction
mode_num = 1;
phi_real = D0*real(Efunc(1:N+1,mode_num));
phi_imag = D0*imag(Efunc(1:N+1,mode_num));

chi_real = D0*real(Efunc(N+2:2*N+2,mode_num));
chi_imag = D0*imag(Efunc(N+2:2*N+2,mode_num));

figure(3),
subplot(1,4,1), plot(phi_real,z), xlabel('Real(\phi_{hat})'), ylabel('z'), ylim([0 ztop]), set(gca,'fontsize',18), hold on
subplot(1,4,2), plot(phi_imag,z), xlabel('Imag(\phi_{hat})'), ylabel('z'), ylim([0 ztop]), set(gca,'fontsize',18), hold on
subplot(1,4,3), plot(chi_real,z), xlabel('Real(\chi_{hat})'), ylabel('z'), ylim([0 ztop]), set(gca,'fontsize',18), hold on
subplot(1,4,4), plot(chi_imag,z), xlabel('Imag(\chi_{hat})'), ylabel('z'), ylim([0 ztop]), set(gca,'fontsize',18), hold on