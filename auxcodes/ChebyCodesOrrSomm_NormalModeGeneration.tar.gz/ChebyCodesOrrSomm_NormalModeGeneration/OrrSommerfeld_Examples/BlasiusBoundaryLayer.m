clear, clc %, close all, format long
%% Input parameters 
alpha = 0.179;    % Wavenumber in x
beta = 0;       % Wavenumber in y
R = 400;   % Reynolds number (set equal to 1E7 for the inviscid case)
N = 1024;         % Number of Chebyshev polynomials

%% Map chebyshev grid to a grid ranging from [-inf,inf]
xi = ChebCollocationPoints(N); % Get the Chebyshev collocation points
[D0,D1,D2,D3,D4]=Dmat(N);      % Get Chebyshev derivative operators

ztop = 250;
shift = ztop/2; scale = ztop/2;
z = ScaleAndShiftMap(xi,scale,shift);
[D0,D1,D2,D3,D4] = getDmat_scale_and_shift(scale,xi,D0,D1,D2,D3,D4);


%% Set the Base flow (on the mapped grid)
load('BlasiusProfile.mat')
u_base = interp1(zBlas,fBlas(:,2),z,'linear',1);
%u_base = 1/2 - tanh(z)./2;
d2udz2_base = interp1(zBlas,fBlas(:,4),z,'linear',0);
d2udz2_base(end) = 0;

% Generate matrix multiplication operators for the two z-dependent functions
U = sparse(diag(u_base));  
Upp = sparse(diag(d2udz2_base));

%% Create the Orr-sommerfeld operator
k = sqrt(alpha^2 + beta^2); 
L = -(1/(1i*alpha*R))*(D4 - 2*(k^2)*D2 + (k^4)*D0) + U*(D2 - (k^2)*D0) - Upp*D0;
M = D2 - (k^2)*D0;

%% Embed Boundary conditions (Chebyshev-Tau method)
c_spurious = -600*1i; % set the spurious modes far away from the interesting modes

% BC1: w(z=-1) = 0
L(1,:) = c_spurious*D0(1,:); % real part of this is ZERO. 
M(1,:) = D0(1,:);

% BC2: dwdz(z=-1) = 0
L(2,:) = c_spurious*D1(1,:); % real part of this is ZERO. 
M(2,:) = D1(1,:);

% BC3: w(z=+1) = 0
L(N+1,:) = c_spurious*D0(N+1,:); % real part of this is ZERO. 
M(N+1,:) = D0(N+1,:);

% BC4: dwdz(z=+1) = 0
L(N  ,:) = c_spurious*D1(N+1,:); % real part of this is ZERO.
M(N  ,:) = D1(N+1,:);


%% Solve the Eigenvalue problem
tic
OS = M\L;
[v,e] = eig(OS); 
toc
e = diag(e);
[~,idx] = sort(imag(e),'descend'); % sort the eigenvalues with largest first. 
Efunc = v(:,idx); Eval = e(idx);
disp('First 20 least stable modes:')
disp(Eval(1:20))
disp(strcat('Growth rate=',num2str(imag(Eval(1))*alpha)))

%% Plot the eigenvalues
figure(2), hold on, plot(real(Eval),imag(Eval),'x'), grid on
xlabel('c_r'), ylabel('c_i'), box on
xlim([0 1.1]), ylim([-0.8,max(imag(Eval))+0.05]), daspect([1 1 1])
set(gca,'fontsize',18)

%% Plot the eigenfunction 
mode_num = 20;
w_real = D0*real(Efunc(:,mode_num));
w_imag = D0*imag(Efunc(:,mode_num));

w_normalize = w_real(N/2+1);
w_real = w_real/w_normalize;
w_imag = w_imag/w_normalize;
figure(3), 
subplot(1,2,1), plot(w_real,z), xlabel('Real(w_{hat})'), ylabel('z'), ylim([0 80]), set(gca,'fontsize',18), hold on
subplot(1,2,2), plot(w_imag,z), xlabel('Imag(w_{hat})'), ylabel('z'), ylim([0 80]), set(gca,'fontsize',18)