%% Tanh mixing layer (Atmospheric Problem)
%  Validation References: 
%  1) Michalke, A., J. Fluid Mech. (1964)
%  2) Criminale, Jackson and Joslin (Cambridge Univ. Press, 2003), pp. 61
clear, clc, close all, format long
%% Input parameters 
alpha = 0.4;    % Wavenumber in x
beta = 0;       % Wavenumber in y
R = 1E2;   % Reynolds number (set equal to 1E7 for the inviscid case)
N = 128;         % Number of Chebyshev polynomials

%% Map chebyshev grid to a grid ranging from [-inf,inf]
xi = ChebCollocationPoints(N); % Get the Chebyshev collocation points
[D0,D1,D2,D3,D4]=Dmat(N);      % Get Chebyshev derivative operators

z = InfiniteMap_algebraic(xi);
[D0,D1,D2,D3,D4] = getDmat_InfiniteMap_algebraic(xi,D0,D1,D2,D3,D4);

%z = InfiniteMap_exponential(xi);
%[D0,D1,D2,D3,D4] = getDmat_InfiniteMap_exponential(xi,D0,D1,D2,D3,D4);
plot_mapped_collocation_points(xi,z,1) % Plot the mapped collocation points

%% Set the Base flow (on the mapped grid)
u_base = 1/2 - tanh(z)./2;
d2udz2_base = D2*fct(u_base);

% Generate matrix multiplication operators for the two z-dependent functions
U = sparse(diag(u_base));  
Upp = sparse(diag(d2udz2_base));

%% Create the Orr-sommerfeld operator
k = sqrt(alpha^2 + beta^2); 
L = -(1/(1i*alpha*R))*(D4 - 2*(k^2)*D2 + (k^4)*D0) + U*(D2 - (k^2)*D0) - Upp*D0;
M = D2 - (k^2)*D0;

%% Embed Boundary conditions (Chebyshev-Tau method)
c_spurious = -600*1i; % set the spurious modes far away from the interesting modes

% NOTE: The [-1,1] -> [-inf,+inf] map builds in the dwdz = 0 BC at +/- infinity
% BC1: w(z=-1) = 0
L(1,:) = c_spurious*D0(1,:); % real part of this is ZERO. 
M(1,:) = D0(1,:);

% BC2: w(z=+1) = 0
L(N+1,:) = c_spurious*D0(N+1,:); % real part of this is ZERO. 
M(N+1,:) = D0(N+1,:);

%% Solve the Eigenvalue problem
OS = M\L;
disp(strcat('Condition number of the Orr-Sommerfeld operator:',num2str(cond(OS),'%10.5e')))
[v,e] = eig(OS); e = diag(e);
[~,idx] = sort(imag(e),'descend'); % sort the eigenvalues with largest first. 
Efunc = v(:,idx); Eval = e(idx);
disp('First 8 least stable modes:')
disp(Eval(1:8))
disp(strcat('Growth rate=',num2str(imag(Eval(1))*alpha)))

%% Plot the eigenvalues
figure(2), hold on, plot(real(Eval),imag(Eval),'x'), grid on
xlabel('c_r'), ylabel('c_i'), box on
xlim([0 1]), ylim([-0.2,max(imag(Eval))+0.05]), daspect([3 1 1])
set(gca,'fontsize',18)

%% Plot the eigenfunction 
w_real = D0*real(Efunc(:,1));
w_imag = D0*imag(Efunc(:,1));

w_normalize = w_real(N/2+1);
w_real = w_real/w_normalize;
w_imag = w_imag/w_normalize;
figure(3), 
subplot(1,2,1), plot(w_real,z), xlabel('Real(w_{hat})'), ylabel('z'), ylim([-25 25]), xlim([-0.05 1.05]), set(gca,'fontsize',18)
subplot(1,2,2), plot(w_imag,z), xlabel('Imag(w_{hat})'), ylabel('z'), ylim([-25 25]), xlim([-0.5 0.5]), set(gca,'fontsize',18)


u_imag = (1/alpha)*D1*fct(w_real);
u_real = (1/alpha)*D1*fct(w_imag);
figure, plot(u_imag,z), ylim([-15 15])