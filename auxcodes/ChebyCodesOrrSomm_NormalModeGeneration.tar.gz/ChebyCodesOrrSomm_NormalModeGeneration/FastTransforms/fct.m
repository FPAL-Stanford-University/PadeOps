function uh = fct(u)
% Fast Chebyshev transform using N*log(N) operations 
u = u(:);
n  = length(u);
u  = ifft([u([n:-1:1 2:n-1])]);
uh = ([u(1); 2*u(2:(n-1)); u(n)]);
return
