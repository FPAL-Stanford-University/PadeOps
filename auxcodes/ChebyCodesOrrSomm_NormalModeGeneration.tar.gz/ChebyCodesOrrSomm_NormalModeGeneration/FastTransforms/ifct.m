function u = ifct(uh)
% Fast Inverse Chebyshev transform using N*log(N) operations 
n = length(uh);
u=fft([uh(1); [uh(2:n-1); uh(n)*2; uh(n-1:-1:2)]*0.5]); 
u=(u(n:-1:1)); 
return
